#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
娱乐插件 for LinDream
包含数字炸弹等小游戏
"""

import random
import json
from datetime import datetime

# 插件配置
PLUGIN_CONFIG = {
    "name": "fun_game",
    "description": "娱乐游戏插件",
    "version": "1.0.0",
    "author": "LinDream",
    "commands": ["/fun"]
}

# 游戏状态存储
game_states = {}

def on_message(websocket, data, bot_id):
    """
    处理消息事件
    :param websocket: WebSocket连接
    :param data: 消息数据
    :param bot_id: 机器人ID
    :return: True if handled, False otherwise
    """
    # 检查是否是消息类型
    if data.get("post_type") != "message":
        return False
    
    # 获取消息内容
    message = data.get("message", "")
    if isinstance(message, list):
        # 如果是消息数组，提取文本内容
        text_content = ""
        for item in message:
            if item.get("type") == "text":
                text_content += item.get("data", {}).get("text", "")
        message = text_content
    
    # 检查是否包含娱乐插件命令
    if message.startswith("/fun"):
        # 提取命令参数
        parts = message.split(" ", 1)
        command = parts[0].lower()
        args = parts[1].strip() if len(parts) > 1 else ""
        
        if args.lower() == "help":
            reply = get_help_text()
        elif args.startswith("bomb"):
            reply = handle_bomb_game(data, args)
        elif args == "":
            # 如果没有参数，显示帮助
            reply = get_help_text()
        else:
            reply = f"未知命令: {args}，发送 /fun help 查看帮助。"
        
        # 发送回复
        import asyncio
        asyncio.create_task(send_reply(websocket, data, reply))
        return True
    
    # 检查是否是游戏回复（非命令消息）
    if not message.startswith("/"):
        user_id = data.get("user_id") or data.get("group_id")
        user_id = str(user_id)  # 确保是字符串类型
        
        # 检查用户是否在游戏中
        if user_id in game_states:
            game_info = game_states[user_id]
            if game_info["game_type"] == "bomb" and game_info["active"]:
                try:
                    # 尝试解析数字
                    guess = int(message.strip())
                    reply = handle_bomb_guess(user_id, guess, game_info)
                    import asyncio
                    asyncio.create_task(send_reply(websocket, data, reply))
                    return True
                except ValueError:
                    # 如果不是数字，忽略
                    pass
    
    return False

def get_help_text():
    """获取插件帮助文本"""
    help_text = """娱乐插件帮助 - /fun
==================
游戏列表:
1. 数字炸弹 (/fun bomb) - 猜数字游戏
   - /fun bomb start - 开始游戏
   - /fun bomb status - 查看游戏状态
   - /fun bomb end - 结束游戏

2. 更多游戏即将添加...

游戏规则:
- 数字炸弹: 机器人设置一个随机数字作为"炸弹"，玩家轮流猜测
- 如果猜中炸弹数字，该玩家"爆炸"失败
- 如果猜的数字不在范围内，范围会缩小
- 猜中范围端点数字的玩家需要重新设置炸弹范围
"""
    return help_text

def handle_bomb_game(data, args):
    """处理数字炸弹游戏命令"""
    args_parts = args.split(" ", 1)
    action = args_parts[1] if len(args_parts) > 1 else "start"
    
    user_id = str(data.get("user_id") or data.get("group_id"))
    group_id = data.get("group_id")
    
    if action == "start":
        # 开始新游戏
        min_val = 1
        max_val = 100
        bomb_num = random.randint(min_val + 1, max_val - 1)  # 炸弹不能是边界值
        
        game_states[user_id] = {
            "game_type": "bomb",
            "active": True,
            "min": min_val,
            "max": max_val,
            "bomb": bomb_num,
            "player": data.get("user_id"),
            "player_name": data.get("sender", {}).get("nickname", "玩家")
        }
        
        return f"🎮 数字炸弹游戏开始！\n范围: {min_val} - {max_val}\n炸弹已经设置，快猜猜它在哪个数字？"
    
    elif action == "status":
        # 查看游戏状态
        if user_id in game_states and game_states[user_id]["active"]:
            game_info = game_states[user_id]
            return f"🎮 数字炸弹游戏状态:\n当前范围: {game_info['min']} - {game_info['max']}\n玩家: {game_info['player_name']}\n游戏进行中..."
        else:
            return "当前没有进行中的数字炸弹游戏，使用 /fun bomb start 开始游戏。"
    
    elif action == "end":
        # 结束游戏
        if user_id in game_states:
            game_states[user_id]["active"] = False
            del game_states[user_id]
        return "🎮 数字炸弹游戏已结束。"
    
    else:
        return f"未知命令: {action}，使用 /fun help 查看帮助。"

def handle_bomb_guess(user_id, guess, game_info):
    """处理数字炸弹猜测"""
    min_val = game_info["min"]
    max_val = game_info["max"]
    bomb_num = game_info["bomb"]
    
    if guess == bomb_num:
        # 猜中炸弹，游戏结束
        game_info["active"] = False
        if user_id in game_states:
            del game_states[user_id]
        return f"💥 BOOM! {guess} 是炸弹！你爆炸了！游戏结束！"
    elif min_val < guess < bomb_num:
        # 猜小了，更新最小值
        game_info["min"] = guess
        return f"📈 {guess} 太小了！新的范围: {game_info['min']} - {game_info['max']}，继续猜吧！"
    elif bomb_num < guess < max_val:
        # 猜大了，更新最大值
        game_info["max"] = guess
        return f"📉 {guess} 太大了！新的范围: {game_info['min']} - {game_info['max']}，继续猜吧！"
    elif guess <= min_val or guess >= max_val:
        # 猜了边界值或超出范围，让该玩家重新设置范围
        game_info["active"] = False
        if user_id in game_states:
            del game_states[user_id]
        return f"⚠️ {guess} 是范围边界值或超出范围！需要重新设置炸弹范围！请使用 /fun bomb start 重新开始游戏。"
    else:
        # 其他情况
        return f"🤔 {guess} 不在当前范围内！当前范围: {game_info['min']} - {game_info['max']}"

def on_load():
    """插件加载时的初始化"""
    print("娱乐游戏插件已加载")

def on_command(websocket, data, command, bot_id):
    """
    处理命令
    :param websocket: WebSocket连接
    :param data: 消息数据
    :param command: 命令内容
    :param bot_id: 机器人ID
    :return: True if handled, False otherwise
    """
    # 重用 on_message 的功能
    return False  # 使用 on_message 处理

async def send_reply(websocket, data, reply):
    """
    发送回复
    :param websocket: WebSocket连接
    :param data: 原始消息数据
    :param reply: 回复内容
    """
    try:
        # 构造回复消息
        if data.get("message_type") == "group":
            msg_data = {
                "action": "send_group_msg",
                "params": {
                    "group_id": data.get("group_id"),
                    "message": reply
                }
            }
        else:
            msg_data = {
                "action": "send_private_msg",
                "params": {
                    "user_id": data.get("user_id"),
                    "message": reply
                }
            }
        
        await websocket.send(json.dumps(msg_data))
    except Exception as e:
        print(f"发送回复时出错: {e}")

if __name__ == "__main__":
    # 测试插件功能
    print("娱乐游戏插件测试")
    print(get_help_text())
