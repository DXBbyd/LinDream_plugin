#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
群成员欢迎插件 for LinDream
当有新成员加入群聊时自动发送欢迎消息
"""

import json
import random
from datetime import datetime

# 插件配置
PLUGIN_CONFIG = {
    "name": "welcome",
    "description": "群成员欢迎插件 - 自动发送欢迎消息",
    "version": "1.0.0",
    "author": "LinDream",
    "events": ["group_increase"]
}

# 欢迎消息模板
WELCOME_MESSAGES = [
    "🎉 欢迎 @name 加入本群！",
    "👏 热烈欢迎 @name ！",
    "🌟 欢迎 @name 萌新加入我们！",
    "🎈 欢迎 @name，希望你在这里玩得开心！",
    "🎊 @name 欢迎光临！",
    "💡 @name 来了，世界都亮了！",
    "🚀 @name 欢迎登上我们的飞船！",
    "🌈 @name 欢迎加入这个大家庭！",
    "🎁 欢迎 @name，这里有好多有趣的朋友！",
    "🔥 @name 到此一游，欢迎欢迎！"
]

def on_message(websocket, data, bot_id):
    """
    处理消息事件
    :param websocket: WebSocket连接
    :param data: 消息数据
    :param bot_id: 机器人ID
    :return: True if handled, False otherwise
    """
    # 检查是否是群成员增加事件
    if (data.get("post_type") == "notice" and 
        data.get("notice_type") == "group_increase"):
        
        group_id = data.get("group_id")
        user_id = data.get("user_id")
        operator_id = data.get("operator_id")
        
        # 获取群名称和用户名称（如果可能）
        # 这里我们模拟一个群名和用户名
        group_name = f"群{group_id}"
        user_name = f"用户{user_id}"
        
        # 获取欢迎消息
        welcome_msg = get_welcome_message(user_name)
        
        # 发送欢迎消息
        import asyncio
        asyncio.create_task(send_welcome_message(websocket, group_id, welcome_msg))
        
        print(f"[群成员欢迎] {group_name}({group_id}) 新成员: {user_name}({user_id})")
        return True
    
    return False

def get_welcome_message(user_name):
    """
    获取随机欢迎消息
    :param user_name: 用户名
    :return: 欢迎消息
    """
    # 随机选择一条欢迎消息并替换@name为实际用户名
    message = random.choice(WELCOME_MESSAGES)
    return message.replace("@name", user_name)

def format_welcome_message(user_name, group_name=None):
    """
    格式化欢迎消息
    :param user_name: 用户名
    :param group_name: 群名称
    :return: 格式化的欢迎消息
    """
    welcome_msg = get_welcome_message(user_name)
    
    # 添加时间戳
    now = datetime.now().strftime("%H:%M")
    formatted_msg = f"{welcome_msg}\n⏰ {now}"
    
    return formatted_msg

async def send_welcome_message(websocket, group_id, message):
    """
    发送欢迎消息到群聊
    :param websocket: WebSocket连接
    :param group_id: 群ID
    :param message: 消息内容
    """
    try:
        msg_data = {
            "action": "send_group_msg",
            "params": {
                "group_id": group_id,
                "message": message
            }
        }
        
        await websocket.send(json.dumps(msg_data))
    except Exception as e:
        print(f"发送欢迎消息时出错: {e}")

def on_load():
    """插件加载时的初始化"""
    print("群成员欢迎插件已加载")
    print(f"已配置 {len(WELCOME_MESSAGES)} 条欢迎消息")

def on_command(websocket, data, command, bot_id):
    """
    处理命令
    :param websocket: WebSocket连接
    :param data: 消息数据
    :param command: 命令内容
    :param bot_id: 机器人ID
    :return: True if handled, False otherwise
    """
    # 欢迎插件不处理命令
    return False
