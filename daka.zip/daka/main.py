"""
打卡插件
每日打卡插件，包含头像显示、累计打卡和一言功能
"""

import requests
import json
import os
from datetime import datetime

# 定义插件触发指令
plugin_cmd = "打卡"

# 确保头像缓存目录存在
AVATAR_DIR = os.path.join("file", "picture", "avatars")
os.makedirs(AVATAR_DIR, exist_ok=True)

def on_load():
    """插件加载时调用"""
    print("[插件系统] 打卡插件已加载")

def get_user_avatar(user_id):
    """获取用户头像URL - 返回头像的URL而不是本地文件路径"""
    # 使用QQ头像API
    avatar_url = f"http://q1.qlogo.cn/g?b=qq&nk={user_id}&s=640"
    
    # 生成本地文件路径
    avatar_filename = f"avatar_{user_id}.jpg"
    avatar_path = os.path.join(AVATAR_DIR, avatar_filename)
    
    # 如果头像文件不存在或超过1天，重新下载
    if not os.path.exists(avatar_path) or (datetime.now().timestamp() - os.path.getmtime(avatar_path)) > 86400:
        try:
            response = requests.get(avatar_url, timeout=10)
            if response.status_code == 200:
                with open(avatar_path, 'wb') as f:
                    f.write(response.content)
                print(f"已下载并缓存头像: {avatar_filename}")
            else:
                print(f"获取头像失败，HTTP状态码: {response.status_code}")
        except Exception as e:
            print(f"下载头像失败: {e}")
    
    # 返回头像的URL，而不是本地路径，以确保在proot环境中也能正常工作
    return avatar_url

def get_user_data(user_id):
    """获取用户打卡数据"""
    data_file = "daka_data.json"
    if os.path.exists(data_file):
        with open(data_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
            return data.get(str(user_id), {"total_days": 0, "last_daka": ""})
    else:
        return {"total_days": 0, "last_daka": ""}

def save_user_data(user_id, user_data):
    """保存用户打卡数据"""
    data_file = "daka_data.json"
    data = {}
    if os.path.exists(data_file):
        with open(data_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
    
    data[str(user_id)] = user_data
    
    with open(data_file, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def daka(user_id):
    """执行打卡操作"""
    # 获取用户头像
    avatar_url = get_user_avatar(user_id)
    
    # 获取用户当前数据
    user_data = get_user_data(user_id)
    
    # 检查今天是否已经打卡
    today = datetime.now().strftime("%Y-%m-%d")
    if user_data["last_daka"] == today:
        # 如果今天已经打卡，返回提示信息
        result = {
            "avatar_url": avatar_url,
            "message": "今天已经打过卡啦！",
            "total_days": user_data["total_days"],
            "date": today,
            "hitokoto": "坚持打卡，养成好习惯！"
        }
        return result
    
    # 更新打卡数据
    user_data["total_days"] += 1
    user_data["last_daka"] = today
    save_user_data(user_id, user_data)
    
    # 获取一言
    hitokoto = get_hitokoto()
    
    # 构建返回结果
    result = {
        "avatar_url": avatar_url,
        "message": "打卡成功！",
        "total_days": user_data["total_days"],
        "date": today,
        "hitokoto": hitokoto
    }
    
    return result

def get_hitokoto():
    """获取一言"""
    try:
        response = requests.get("https://v1.hitokoto.cn/?c=d&encode=json", timeout=5)
        if response.status_code == 200:
            data = response.json()
            return f"{data['hitokoto']} —— {data['from']}"
    except requests.exceptions.RequestException as e:
        print(f"网络请求错误: {e}")
    except Exception as e:
        print(f"获取一言失败: {e}")
    return "今日份的鸡汤来啦！"

def format_output(result):
    """格式化输出结果"""
    # 使用头像URL构造CQ码
    avatar_url = result.get('avatar_url')
    if avatar_url:
        # 构造CQ码格式的图片消息，使用URL
        avatar_cq = f"[CQ:image,file={avatar_url}]"
    else:
        # 如果头像URL不存在，只显示文字内容
        avatar_cq = "👤 [头像] "
    
    # 获取一言
    hitokoto = get_hitokoto()
    
    output = f"""{avatar_cq}
━━━━━━━━━━━━━━━
      🎉 打卡成功 🎉
━━━━━━━━━━━━━━━

📅打卡日期: {result['date']}
📊累计打卡: {result['total_days']} 天

💬 今日一言:
❝ {hitokoto} ❞

━━━━━━━━━━━━━━━
        继续加油! 💪
━━━━━━━━━━━━━━━"""
    return output

def on_message(websocket, data, bot_id):
    """
    处理消息的函数
    :param websocket: WebSocket连接
    :param data: 消息数据
    :param bot_id: 机器人ID
    :return: True表示消息已被处理，False表示未处理
    """
    # 检查是否为消息事件
    if data.get("post_type") != "message":
        return False
    
    # 获取消息内容
    message_content = ""
    if isinstance(data.get("message"), list):
        for msg_item in data.get("message", []):
            if msg_item.get("type") == "text":
                message_content = msg_item.get("data", {}).get("text", "").strip()
                break
    else:
        message_content = str(data.get("message", "")).strip()
    
    # 检查是否是打卡指令
    if message_content in ["打卡", "daka", "签到"]:
        import asyncio
        
        # 获取用户ID
        user_id = data.get("user_id", "unknown")
        
        # 执行打卡操作
        result = daka(user_id)
        formatted_output = format_output(result)
        
        async def send_reply():
            # 准备发送消息
            reply_data = {
                "action": "send_group_msg" if data.get("message_type") == "group" else "send_private_msg",
                "params": {
                    "message": formatted_output,
                }
            }
            
            if data.get("message_type") == "group":
                reply_data["params"]["group_id"] = data.get("group_id")
            else:
                reply_data["params"]["user_id"] = data.get("user_id")
            
            import json
            await websocket.send(json.dumps(reply_data))
        
        # 异步发送回复
        asyncio.create_task(send_reply())
        return True  # 表示消息已被处理
    
    return False  # 表示消息未被处理

def on_command(websocket, data, command, bot_id):
    """
    处理插件命令的函数
    :param websocket: WebSocket连接
    :param data: 消息数据
    :param command: 命令内容
    :param bot_id: 机器人ID
    :return: True表示命令已被处理，False表示未处理
    """
    if command in ["打卡", "daka", "签到", ""]:
        import asyncio
        
        # 获取用户ID
        user_id = data.get("user_id", "unknown")
        
        # 执行打卡操作
        result = daka(user_id)
        formatted_output = format_output(result)
        
        async def send_reply():
            # 准备发送消息
            reply_data = {
                "action": "send_group_msg" if data.get("message_type") == "group" else "send_private_msg",
                "params": {
                    "message": formatted_output,
                }
            }
            
            if data.get("message_type") == "group":
                reply_data["params"]["group_id"] = data.get("group_id")
            else:
                reply_data["params"]["user_id"] = data.get("user_id")
            
            import json
            await websocket.send(json.dumps(reply_data))
        
        # 异步发送回复
        asyncio.create_task(send_reply())
        return True  # 表示命令已被处理
    
    return False  # 表示命令未被处理