伪群友聊天补丁使用说明
=====================

补丁名称: pseudo_friend
版本: betaV1.0
功能: 实现沉浸式群聊体验，强化记忆系统为"活性忆泡"2，添加温度控制等

配置说明
--------
补丁配置文件: patches/pseudo_friend/config.json

- enabled: 是否启用补丁 (默认: false)
- temperature: 聊天温度，控制回复频率和主动性 (默认: 0.7)
- active_memory_bubbles: 活跃记忆泡数量 (默认: 2)  
- persona_file: 使用的人格文件 (默认: "default.txt")
- enable_active_reply: 是否启用主动回复 (默认: true)
- disable_plugins: 是否禁用插件 (默认: true)
- disable_auto_reply: 是否禁用自动回复 (默认: true) 
- disable_poke_reply: 是否禁用戳一戳回复 (默认: true)
- disable_commands: 是否禁用指令 (默认: true)
- disable_percent_prefix: 是否禁用百分号前缀AI (默认: true)

人格文件
--------
在 patches/pseudo_friend/persona/ 目录下存放人格文件
当前使用 patches/pseudo_friend/persona/default.txt

使用方法
--------
1. 修改 config.json 将 enabled 设为 true 来启用补丁
2. 修改 personality 文件来自定义人格
3. 调整 temperature 来控制聊天活跃度
4. 重启程序使配置生效

注意
----
此补丁会覆盖主程序的部分功能：
- 禁用插件系统
- 禁用自动回复规则
- 禁用戳一戳随机回复
- 禁用指令系统
- 禁用%前缀AI触发
- 使用独立的记忆系统（活性忆泡）