"""
伪群友聊天补丁 - 实现沉浸式群聊体验
版本: betaV1.0
"""
import json
import os
import asyncio
import random
import datetime
import httpx
from colorama import init, Fore, Style

# 初始化 colorama
init(autoreset=True)

# 全局变量
patch_config = {}
applied = False
persona_content = ""
active_memory_bubbles = []
last_active_reply_time = {}
current_group_sessions = {}  # 每个群的独立会话
message_cache = {}  # 消息缓存
websocket_instance = None  # WebSocket实例，用于主动回复

def log_platform_info(text):
    """日志输出函数"""
    msg = f"[伪群友补丁] {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | {text}"
    print(Fore.LIGHTYELLOW_EX + Style.BRIGHT + "  ▶ " + msg)

def patch_apply():
    """应用补丁"""
    global applied, patch_config, persona_content, active_memory_bubbles
    try:
        # 读取补丁配置
        config_path = os.path.join(os.path.dirname(__file__), "config.json")
        if os.path.exists(config_path):
            with open(config_path, "r", encoding="utf-8") as f:
                patch_config = json.load(f)
        
        # 检查是否启用补丁
        if not patch_config.get("enabled", False):
            log_platform_info("伪群友补丁在配置中未启用")
            return
        
        # 读取人格文件
        persona_file = patch_config.get("persona_file", "default.txt")
        persona_path = os.path.join(os.path.dirname(__file__), "persona", persona_file)
        if os.path.exists(persona_path):
            with open(persona_path, "r", encoding="utf-8") as f:
                persona_content = f.read().strip()
        else:
            log_platform_info(f"人格文件不存在: {persona_path}")
            return
            
        # 初始化活跃记忆泡
        active_memory_bubbles = []
        
        applied = True
        log_platform_info("伪群友补丁已应用，版本: betaV1.0")
        log_platform_info(f"当前人格: {persona_file}")
        log_platform_info(f"活跃记忆泡数量: {patch_config.get('active_memory_bubbles', 2)}")
        log_platform_info(f"温度设置: {patch_config.get('temperature', 0.7)}")
    except Exception as e:
        log_platform_info(f"应用补丁失败: {e}")

def patch_unapply():
    """卸载补丁"""
    global applied
    applied = False
    log_platform_info("伪群友补丁已卸载")

def is_patch_applied():
    """检查补丁是否已应用"""
    return applied

def should_disable_feature(feature_name, group_id=None):
    """检查是否应该禁用某个功能"""
    if not applied:
        return False
    
    # 如果是群聊消息且不在允许列表中，则禁用所有功能
    if group_id and not is_group_allowed(group_id):
        return True
    
    return patch_config.get(f"disable_{feature_name}", True)

def get_temperature():
    """获取温度值"""
    if not applied:
        return 0.7  # 默认值
    return patch_config.get("temperature", 0.7)

def get_active_memory_bubbles():
    """获取活跃记忆泡数量"""
    if not applied:
        return 2
    return patch_config.get("active_memory_bubbles", 2)

def get_persona_content():
    """获取人格内容"""
    return persona_content

def update_active_memory(message_data):
    """更新活跃记忆泡"""
    global active_memory_bubbles
    if not applied:
        return
        
    # 添加新消息到活跃记忆泡
    active_memory_bubbles.append({
        "time": datetime.datetime.now(),
        "data": message_data
    })
    
    # 限制活跃记忆泡数量
    max_bubbles = get_active_memory_bubbles()
    if len(active_memory_bubbles) > max_bubbles:
        active_memory_bubbles = active_memory_bubbles[-max_bubbles:]

def get_active_memory():
    """获取当前活跃记忆"""
    return active_memory_bubbles

def is_group_allowed(group_id):
    """检查群聊是否被允许使用功能（单一群聊模式）"""
    if not applied:
        return False
    
    # 如果不是单一群聊模式，则使用原来的黑名单逻辑
    if not patch_config.get("single_group_mode", False):
        return not is_group_blacklisted(group_id)
    
    # 单一群聊模式：只允许指定的群聊
    allowed_group = patch_config.get("allowed_group", "")
    return str(group_id) == str(allowed_group)

def is_group_blacklisted(group_id):
    """检查群聊是否在黑名单中"""
    if not applied:
        return False
    
    blacklist = patch_config.get("blacklist_groups", [])
    return str(group_id) in [str(gid) for gid in blacklist]

def should_respond_to_message(message_content, group_id=None, message_data=None):
    """根据温度判断是否回复消息"""
    if not applied:
        return False
    
    # 如果指定了群ID，检查是否被允许使用功能
    if group_id and not is_group_allowed(group_id):
        return False
    
    temperature = get_temperature()
    
    # 如果温度为1，则总是回复
    if temperature >= 1.0:
        return True
    
    # 如果是私聊，使用更高的回复概率
    is_private_chat = group_id is None
    
    # 检查消息中是否包含艾特机器人或引用机器人消息
    has_at_bot = False
    has_reply_to_bot = False
    
    if message_data:
        message = message_data.get("message", [])
        if isinstance(message, list):
            for msg_part in message:
                if msg_part.get("type") == "at":
                    # 检查是否艾特了机器人
                    at_qq = msg_part.get("data", {}).get("qq", "")
                    if at_qq == str(message_data.get("self_id", "")):
                        has_at_bot = True
                elif msg_part.get("type") == "reply":
                    # 检查是否引用了机器人的消息
                    reply_id = msg_part.get("data", {}).get("id", "")
                    # 这里需要检查被引用的消息是否是机器人发送的
                    # 由于无法直接获取历史消息，我们假设有回复就增加概率
                    has_reply_to_bot = True
    
    # 如果消息艾特机器人或引用机器人消息，则增加回复概率
    if has_at_bot or has_reply_to_bot:
        # 艾特或引用机器人时，大幅提高回复概率
        base_probability = temperature * 2.0 if is_private_chat else temperature * 1.8
        return random.random() < min(1.0, base_probability)  # 最大不超过1.0
    
    # 如果消息提及机器人，则更有可能回复
    if "bot" in message_content.lower() or "机器人" in message_content or "你" in message_content:
        # 增加回复概率
        base_probability = temperature * 1.5 if is_private_chat else temperature
        return random.random() < min(1.0, base_probability)  # 最大不超过1.0
    
    # 私聊场景下，使用相对较高的回复概率
    if is_private_chat:
        # 对于私聊，提高回复概率，例如使用温度值的1.2倍
        return random.random() < min(1.0, temperature * 1.2)
    
    # 基于温度的随机判断（群聊）
    return random.random() < temperature

async def should_initiate_conversation(group_id, time_threshold_minutes=15):
    """判断是否应该主动发起对话"""
    if not applied or not patch_config.get("enable_active_reply", True):
        return False
    
    # 检查该群最近是否主动回复过
    last_time = last_active_reply_time.get(group_id, None)
    if last_time:
        time_since_last = datetime.datetime.now() - last_time
        if time_since_last < datetime.timedelta(minutes=time_threshold_minutes):
            # 如果最近已主动回复，降低频率
            return False
    
    # 基于温度决定是否主动发起对话
    temperature = get_temperature()
    # 主动发起对话的概率基于温度，但会适当调整
    return random.random() < (temperature * 0.4)  # 主动发起对话的概率适中

def record_active_reply(group_id):
    """记录主动回复时间"""
    global last_active_reply_time
    last_active_reply_time[group_id] = datetime.datetime.now()

def format_message(msg):
    """格式化消息内容（从主程序复制）"""
    if isinstance(msg, list):
        parts = []
        for m in msg:
            tp = m.get("type")
            data = m.get("data", {})

            if tp == "text":
                parts.append(data.get("text", ""))
            elif tp == "at":
                parts.append(f"@{data.get('qq','未知')} ")
            elif tp == "reply":
                parts.append(f"[引用:{data.get('id','未知')}]")
            elif tp == "image":
                parts.append(f"[图片] {data.get('url') or data.get('file','')}")
            elif tp == "json":
                try:
                    inner = json.loads(data.get("data","{}"))
                    meta = inner.get("meta", {}).get("contact", {})
                    nickname = meta.get("nickname","")
                    tag = meta.get("tag","")
                    jump = meta.get("jumpUrl","")
                    parts.append(f"[JSON卡片] {nickname} | {tag} | {jump}")
                except:
                    parts.append("[JSON卡片]")
            else:
                parts.append(f"[{tp}]")
        return "".join(parts)
    elif isinstance(msg, dict):
        return json.dumps(msg, ensure_ascii=False)
    else:
        return str(msg)

def get_group_session(group_id):
    """获取群聊会话（模仿主程序逻辑）"""
    global current_group_sessions
    if group_id not in current_group_sessions:
        current_group_sessions[group_id] = {
            "history": [],
            "persona": "pseudo_friend"  # 使用伪群友人格
        }
    return current_group_sessions[group_id]

def get_user_session(user_id):
    """获取用户会话（模仿主程序逻辑）"""
    # 为保持一致性，我们也用独立的用户会话字典
    if not hasattr(get_user_session, 'current_user_sessions'):
        get_user_session.current_user_sessions = {}
    
    if user_id not in get_user_session.current_user_sessions:
        get_user_session.current_user_sessions[user_id] = {
            "history": [],
            "persona": "pseudo_friend"  # 使用伪群友人格
        }
    return get_user_session.current_user_sessions[user_id]

def update_session_history(session, user_message, ai_response):
    """更新会话历史（模仿主程序逻辑）"""
    session["history"].append({"user": user_message, "ai": ai_response})
    # 限制历史记录长度
    if len(session["history"]) > 10:
        session["history"] = session["history"][-10:]

def get_active_reply_context(group_id):
    """获取主动回复的上下文"""
    if not applied:
        return ""
    
    # 获取最近的活跃记忆泡作为上下文
    recent_bubbles = active_memory_bubbles[-3:] if len(active_memory_bubbles) >= 3 else active_memory_bubbles
    context_parts = []
    
    for bubble in recent_bubbles:
        data = bubble["data"]
        message_text = format_message(data.get("message", ""))
        sender = data.get("sender", {}).get("nickname", data.get("sender", {}).get("card", "未知"))
        context_parts.append(f"{sender}说: {message_text}")
    
    return "\n".join(context_parts)

async def chat_with_ai(message, api_key, api_url, model_name, session=None):
    """与AI进行对话（模仿主程序逻辑）"""
    if not api_key or not applied:
        return None
        
    try:
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        
        # 构建消息历史
        messages = []
        
        # 添加人格设定
        if persona_content:
            messages.append({"role": "system", "content": persona_content})
        
        # 如果有会话历史，添加到消息中
        if session and session.get("history"):
            for interaction in session["history"]:
                messages.append({"role": "user", "content": interaction["user"]})
                messages.append({"role": "assistant", "content": interaction["ai"]})
        
        # 添加当前消息
        messages.append({"role": "user", "content": message})
        
        data = {
            "model": model_name,
            "messages": messages,
            "temperature": get_temperature()  # 使用补丁的温度设置
        }
        
        async with httpx.AsyncClient() as client:
            response = await client.post(api_url, headers=headers, json=data, timeout=30.0)
            if response.status_code == 200:
                result = response.json()
                return result["choices"][0]["message"]["content"]
            else:
                log_platform_info(f"AI聊天API错误: {response.status_code} - {response.text}")
                return None
    except Exception as e:
        log_platform_info(f"AI聊天功能异常: {e}")
        return None

def set_websocket_instance(ws):
    """设置WebSocket实例"""
    global websocket_instance
    websocket_instance = ws

async def process_message(websocket, data, bot_id, config_data):
    """处理消息的主要函数"""
    global websocket_instance
    if not applied:
        return False  # 补丁未应用，不处理消息
    
    websocket_instance = websocket
    
    # 获取群ID和消息类型
    group_id = data.get("group_id")
    message_type = data.get("message_type")
    
    # 如果是群聊消息且不在允许列表中，则不处理
    if message_type == "group" and group_id and not is_group_allowed(group_id):
        return False
    
    # 更新活跃记忆泡
    update_active_memory(data)
    
    # 获取API配置
    api_key = config_data.get("api_key", "")
    api_url = config_data.get("api_url", "https://apis.iflow.cn/v1/chat/completions")
    model_name = config_data.get("model_name", "qwen3-coder-plus")
    
    if not api_key:
        return False  # 没有API密钥，无法处理
    
    message_content = format_message(data.get("message")).strip()
    
    # 获取发送者ID用于私聊
    sender = data.get("sender", {})
    sender_id = sender.get("user_id")
    
    if message_type == "group" and group_id:
        # 群聊消息处理
        
        # 首先判断是否回复当前消息
        if should_respond_to_message(message_content, group_id, data):
            # 获取群会话
            session = get_group_session(group_id)
            
            # 与AI对话
            ai_response = await chat_with_ai(message_content, api_key, api_url, model_name, session)
            if ai_response:
                # 更新会话历史
                update_session_history(session, message_content, ai_response)
                
                # 发送回复
                await send_message(websocket, ai_response, group_id=group_id)
                log_platform_info(f"伪群友回复: {ai_response}")
                record_active_reply(group_id)  # 记录回复时间
                return True
        
        # 检查是否主动发起对话（同样检查是否被允许）
        if is_group_allowed(group_id) and await should_initiate_conversation(group_id):
            # 尝试主动发起对话
            context = get_active_reply_context(group_id)
            
            # 构建主动发起对话的提示
            prompt = f"这是一个群聊环境，以下是最近的对话:\n{context}\n\n请根据以上对话内容，自然地发起一个新话题或回应现有话题，让对话更有趣。"
            
            session = get_group_session(group_id)
            ai_response = await chat_with_ai(prompt, api_key, api_url, model_name, session)
            if ai_response:
                # 更新会话历史
                update_session_history(session, f"主动发起对话: {prompt}", ai_response)
                
                # 发送回复
                await send_message(websocket, ai_response, group_id=group_id)
                log_platform_info(f"伪群友主动回复: {ai_response}")
                record_active_reply(group_id)  # 记录回复时间
                return True
    elif message_type == "private" and sender_id:
        # 私聊消息处理
        
        # 判断是否回复私聊消息（私聊不受黑名单影响）
        if should_respond_to_message(message_content, None, data):
            # 获取用户会话
            session = get_user_session(sender_id)
            
            # 与AI对话
            ai_response = await chat_with_ai(message_content, api_key, api_url, model_name, session)
            if ai_response:
                # 更新会话历史
                update_session_history(session, message_content, ai_response)
                
                # 发送回复
                await send_message(websocket, ai_response, user_id=sender_id)
                log_platform_info(f"伪群友私聊回复: {ai_response}")
                # 记录回复，使用用户ID作为标识
                record_active_reply(sender_id)  # 记录回复时间
                return True
    
    return False  # 消息未被处理

async def send_message(websocket, message, group_id=None, user_id=None):
    """发送消息（模仿主程序逻辑）"""
    try:
        msg_data = {
            "action": "send_group_msg" if group_id else "send_private_msg",
            "params": {}
        }
        
        if group_id:
            msg_data["params"]["group_id"] = group_id
        else:
            msg_data["params"]["user_id"] = user_id
            
        msg_data["params"]["message"] = message
        
        await websocket.send(json.dumps(msg_data))
        return True
    except Exception as e:
        log_platform_info(f"发送消息失败: {e}")
        return False

