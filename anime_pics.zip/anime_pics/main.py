#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
二次元图片插件 for LinDream
支持多个API源的二次元图片获取和发送
"""

import requests
import json
import random
from urllib.parse import urlparse
from io import BytesIO

# 插件配置
PLUGIN_CONFIG = {
    "name": "anime_pics",
    "description": "二次元图片插件",
    "version": "1.0.1",
    "author": "LinDream",
    "commands": ["/pic", "/image", "/二次元", "/随机图", "/图片", "/pichelp"]
}

# API配置
APIS = {
    "alcy_cc": {
        "name": "alcy.cc",
        "urls": [
            "https://t.alcy.cc/",
            "https://t.alcy.cc/mp",
            "https://t.alcy.cc/fj"
        ],
        "type": "image_url",  # 直接返回图片URL
        "description": "alcy.cc 图源"
    },
    "lolicon": {
        "name": "Lolicon",
        "urls": ["https://api.lolicon.app/setu/v2"],
        "type": "json_api",  # 返回JSON数据，需要解析
        "description": "Lolicon 图源"
    },
    "qy_98": {
        "name": "98qy.com",
        "urls": ["http://www.98qy.com/sjbz/api.php"],
        "type": "json_api",  # 返回JSON数据，需要解析
        "description": "98qy.com 图源"
    },
    "nyan_run": {
        "name": "nyan.run",
        "urls": ["https://sex.nyan.run/"],
        "type": "image_url",  # 直接返回图片URL
        "description": "nyan.run 图源"
    }
}

def on_message(websocket, data, bot_id):
    """
    处理消息事件
    :param websocket: WebSocket连接
    :param data: 消息数据
    :param bot_id: 机器人ID
    :return: True if handled, False otherwise
    """
    # 检查是否是消息类型
    if data.get("post_type") != "message":
        return False
    
    # 获取消息内容
    message = data.get("message", "")
    if isinstance(message, list):
        # 如果是消息数组，提取文本内容
        text_content = ""
        for item in message:
            if item.get("type") == "text":
                text_content += item.get("data", {}).get("text", "")
        message = text_content
    
    # 检查是否包含帮助命令
    if message.startswith("/pichelp") or message.startswith("/pic help"):
        help_text = get_help_text()
        import asyncio
        asyncio.create_task(send_reply(websocket, data, help_text))
        return True
    
    # 检查是否包含图片命令
    if any(message.startswith(cmd) for cmd in ["/pic", "/image", "/二次元", "/随机图", "/图片"]):
        # 提取参数
        parts = message.split(" ", 1)
        source = parts[1].strip() if len(parts) > 1 else "random"
        
        # 获取图片
        image_url = get_random_image(source)
        if image_url:
            # 发送图片
            import asyncio
            asyncio.create_task(send_image(websocket, data, image_url))
            return True
        else:
            # 发送错误消息
            import asyncio
            asyncio.create_task(send_reply(websocket, data, "获取图片失败，请稍后重试。"))
            return True
    
    return False

def get_help_text():
    """
    获取插件帮助文本
    :return: 帮助文本
    """
    help_text = """🖼️ 二次元图片插件帮助
==================
命令列表:
• /pic - 随机获取二次元图片
• /image - 随机获取二次元图片
• /二次元 - 随机获取二次元图片
• /随机图 - 随机获取二次元图片
• /图片 - 随机获取二次元图片
• /pic alcy_cc - 从alcy.cc获取图片
• /pic lolicon - 从Lolicon获取图片
• /pic qy_98 - 从98qy.com获取图片
• /pic nyan_run - 从nyan.run获取图片
• /pichelp - 显示此帮助信息

支持图源:
1. alcy.cc - 包含多个子源 (/, /mp, /fj)
2. Lolicon - 绅士向图片API
3. 98qy.com - 随机图片API
4. nyan.run - 随机图片API

注意: 部分图片可能包含不适合所有场合的内容
"""
    return help_text

def get_random_image(source="random"):
    """
    获取随机图片
    :param source: 图源名称或"random"
    :return: 图片URL或None
    """
    try:
        # 如果指定了特定源，使用该源
        if source != "random" and source in APIS:
            api_config = APIS[source]
            url = random.choice(api_config["urls"])
            
            if api_config["type"] == "json_api":
                return get_image_from_json_api(url)
            else:
                return get_image_from_direct_url(url)
        else:
            # 随机选择一个API
            api_name, api_config = random.choice(list(APIS.items()))
            url = random.choice(api_config["urls"])
            
            if api_config["type"] == "json_api":
                return get_image_from_json_api(url)
            else:
                return get_image_from_direct_url(url)
    except Exception as e:
        print(f"获取图片时出错: {e}")
        return None

def get_image_from_json_api(url):
    """
    从JSON API获取图片URL
    :param url: API URL
    :return: 图片URL或None
    """
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        
        response = requests.get(url, headers=headers, timeout=15)
        
        if response.status_code == 200:
            # 检查响应内容类型
            content_type = response.headers.get('content-type', '').lower()
            
            # 如果响应是图片而不是JSON，直接返回URL
            if content_type.startswith('image/'):
                return response.url
            
            try:
                data = response.json()
                
                # 处理Lolicon API
                if "data" in data and isinstance(data["data"], list) and len(data["data"]) > 0:
                    item = data["data"][0]
                    if "urls" in item and "original" in item["urls"]:
                        return item["urls"]["original"]
                    elif "url" in item:
                        return item["url"]
                
                # 处理98qy API
                elif "picurl" in data:
                    return data["picurl"]
                elif "url" in data:
                    return data["url"]
                
                # 其他JSON API格式
                else:
                    # 尝试从返回的JSON中查找可能的图片URL字段
                    for key in data:
                        value = data[key]
                        if isinstance(value, str) and (value.startswith("http") and 
                            any(ext in value.lower() for ext in [".jpg", ".jpeg", ".png", ".gif", ".webp"])):
                            return value
                    print(f"未在JSON响应中找到图片URL: {data}")
                    return None
                    
            except json.JSONDecodeError:
                print(f"无法解析JSON响应，可能是直接图片URL: {response.url}")
                # 如果响应不是JSON，但可能是图片重定向
                if content_type.startswith('image/'):
                    return response.url
                else:
                    print(f"响应内容非JSON也非图片: {content_type[:50]}")
                    return None
        else:
            print(f"API请求失败: {response.status_code} - {url}")
            return None
            
    except requests.exceptions.RequestException as e:
        print(f"请求API时出错: {e}")
        return None
    except Exception as e:
        print(f"处理JSON API时出错: {e}")
        return None

def get_image_from_direct_url(url):
    """
    从直接URL获取图片URL（处理重定向）
    :param url: 图片URL
    :return: 图片URL或None
    """
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        
        # 使用allow_redirects=True来处理重定向
        response = requests.get(url, headers=headers, timeout=15, allow_redirects=True)
        
        # 获取最终URL（处理重定向）
        final_url = response.url
        
        # 检查内容类型是否为图片
        content_type = response.headers.get('content-type', '').lower()
        if content_type.startswith('image/'):
            return final_url
        else:
            # 检查响应是否为图片内容（即使Content-Type不正确）
            # 检查URL扩展名
            if any(ext in final_url.lower() for ext in ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp']):
                return final_url
            else:
                print(f"URL不是图片类型: {final_url}, Content-Type: {content_type}")
                return None
                
    except requests.exceptions.RequestException as e:
        print(f"请求图片URL时出错: {e}")
        return None

async def send_image(websocket, data, image_url):
    """
    发送图片到会话
    :param websocket: WebSocket连接
    :param data: 消息数据
    :param image_url: 图片URL
    """
    try:
        # 构造发送图片的消息
        if data.get("message_type") == "group":
            msg_data = {
                "action": "send_group_msg",
                "params": {
                    "group_id": data.get("group_id"),
                    "message": [
                        {
                            "type": "image",
                            "data": {
                                "file": image_url
                            }
                        }
                    ]
                }
            }
        else:
            msg_data = {
                "action": "send_private_msg",
                "params": {
                    "user_id": data.get("user_id"),
                    "message": [
                        {
                            "type": "image",
                            "data": {
                                "file": image_url
                            }
                        }
                    ]
                }
            }
        
        await websocket.send(json.dumps(msg_data))
    except Exception as e:
        print(f"发送图片时出错: {e}")
        # 如果发送图片失败，尝试发送图片链接
        import asyncio
        asyncio.create_task(send_reply(websocket, data, f"图片获取成功，链接: {image_url}"))

async def send_reply(websocket, data, reply):
    """
    发送回复
    :param websocket: WebSocket连接
    :param data: 原始消息数据
    :param reply: 回复内容
    """
    try:
        # 构造回复消息
        if data.get("message_type") == "group":
            msg_data = {
                "action": "send_group_msg",
                "params": {
                    "group_id": data.get("group_id"),
                    "message": reply
                }
            }
        else:
            msg_data = {
                "action": "send_private_msg",
                "params": {
                    "user_id": data.get("user_id"),
                    "message": reply
                }
            }
        
        await websocket.send(json.dumps(msg_data))
    except Exception as e:
        print(f"发送回复时出错: {e}")

def on_load():
    """插件加载时的初始化"""
    print("二次元图片插件已加载")

def on_command(websocket, data, command, bot_id):
    """
    处理命令
    :param websocket: WebSocket连接
    :param data: 消息数据
    :param command: 命令内容
    :param bot_id: 机器人ID
    :return: True if handled, False otherwise
    """
    # 重用 on_message 的功能
    return False  # 使用 on_message 处理