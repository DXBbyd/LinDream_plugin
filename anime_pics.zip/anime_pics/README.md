# 二次元图片插件

## 功能说明
- 随机发送二次元图片
- 支持多种图片分类

## 使用方法

### 获取图片
- 发送 `/plugin anime_pics` 随机获取一张图片
- 或者指定分类：`/plugin anime_pics [分类名]`

### 图片分类
- 萌图：`/plugin anime_pics moe`
- 风景：`/plugin anime_pics scenery`
- 角色：`/plugin anime_pics character`
- 随机：`/plugin anime_pics random`

## 注意事项
- 图片来源于网络，内容随机
- 请遵守相关法律法规，文明使用
- 图片加载可能需要一定时间，请耐心等待