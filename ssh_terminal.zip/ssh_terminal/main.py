#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SSH终端插件 for LinDream
允许用户通过命令进入和退出SSH会话，并执行终端命令
"""

import subprocess
import shlex
import asyncio
import threading
import queue
import json
from io import StringIO
import sys
import os

# 插件配置
PLUGIN_CONFIG = {
    "name": "ssh_terminal",
    "description": "SSH终端插件 - 执行终端指令",
    "version": "1.0.0",
    "author": "LinDream",
    "commands": ["/ssh"]
}

# 会话管理
active_sessions = {}

# SSH配置
SSH_CONFIG = {
    "host": "127.0.0.1",  # 默认本地
    "port": 22,           # 默认SSH端口，可以更改
    "password": "114514", # 默认密码
    "username": "user"    # 默认用户名
}

def on_message(websocket, data, bot_id):
    """
    处理消息事件
    :param websocket: WebSocket连接
    :param data: 消息数据
    :param bot_id: 机器人ID
    :return: True if handled, False otherwise
    """
    # 检查是否是消息类型
    if data.get("post_type") != "message":
        return False
    
    # 获取消息内容
    message = data.get("message", "")
    if isinstance(message, list):
        # 如果是消息数组，提取文本内容
        text_content = ""
        for item in message:
            if item.get("type") == "text":
                text_content += item.get("data", {}).get("text", "")
        message = text_content
    
    # 获取用户ID
    user_id = data.get("user_id") or data.get("group_id")
    user_id = str(user_id)
    
    # 检查是否包含SSH命令
    if message.startswith("/ssh"):
        parts = message.split(" ", 2)  # 增加分割数量以处理配置参数
        action = parts[1].strip() if len(parts) > 1 else "help"
        
        if action == "start":
            # 开始SSH会话
            if user_id not in active_sessions:
                active_sessions[user_id] = True
                reply = "✅ SSH会话已启动！现在发送的任何消息都将作为终端命令执行。\n发送 /ssh stop 结束会话。"
            else:
                reply = "⚠️ 您已处于SSH会话中。"
            
            import asyncio
            asyncio.create_task(send_reply(websocket, data, reply))
            return True
        
        elif action == "stop":
            # 停止SSH会话
            if user_id in active_sessions:
                del active_sessions[user_id]
                reply = "⏹️ SSH会话已结束。"
            else:
                reply = "❌ 您当前没有活跃的SSH会话。"
            
            import asyncio
            asyncio.create_task(send_reply(websocket, data, reply))
            return True
        
        elif action == "config" and len(parts) > 2:
            # 配置SSH参数
            config_param = parts[2].strip()
            if '=' in config_param:
                key, value = config_param.split('=', 1)
                key = key.strip()
                value = value.strip()
                
                if key in SSH_CONFIG:
                    # 尝试转换数值类型
                    if key == "port":
                        try:
                            SSH_CONFIG[key] = int(value)
                            reply = f"✅ SSH配置已更新: {key} = {SSH_CONFIG[key]}"
                        except ValueError:
                            reply = f"❌ 端口号必须是数字"
                    elif key == "password":
                        SSH_CONFIG[key] = value
                        reply = f"✅ SSH配置已更新: {key} = {SSH_CONFIG[key]}"
                    elif key == "host":
                        SSH_CONFIG[key] = value
                        reply = f"✅ SSH配置已更新: {key} = {SSH_CONFIG[key]}"
                    elif key == "username":
                        SSH_CONFIG[key] = value
                        reply = f"✅ SSH配置已更新: {key} = {SSH_CONFIG[key]}"
                    else:
                        reply = f"❌ 不支持的配置项: {key}"
                else:
                    reply = f"❌ 不支持的配置项: {key}"
            else:
                reply = "❌ 配置格式错误，请使用 /ssh config key=value 格式"
            
            import asyncio
            asyncio.create_task(send_reply(websocket, data, reply))
            return True
        
        elif action == "info":
            # 显示当前SSH配置
            reply = f"""🖥️ SSH配置信息
==================
主机: {SSH_CONFIG['host']}
端口: {SSH_CONFIG['port']}
用户名: {SSH_CONFIG['username']}
密码: {'*' * len(SSH_CONFIG['password'])}  (已隐藏)
"""
            import asyncio
            asyncio.create_task(send_reply(websocket, data, reply))
            return True
        
        elif action == "help" or action == "":
            # 显示帮助
            reply = """🖥️ SSH终端插件帮助
==================
命令列表:
• /ssh start - 开始SSH会话
• /ssh stop - 结束SSH会话
• /ssh config key=value - 配置SSH参数
• /ssh info - 显示当前配置
• /ssh help - 显示此帮助信息

配置项:
• host=主机地址 - 设置SSH主机地址
• port=端口号 - 设置SSH端口号
• username=用户名 - 设置SSH用户名
• password=密码 - 设置SSH密码

使用示例:
• /ssh config host=192.168.1.100
• /ssh config port=2222
• /ssh config username=myuser
• /ssh config password=114514

注意: 目前插件在本地执行命令，如需连接远程SSH服务器，请安装paramiko等SSH库
"""
            import asyncio
            asyncio.create_task(send_reply(websocket, data, reply))
            return True
    
    # 检查用户是否在SSH会话中
    if user_id in active_sessions and active_sessions[user_id]:
        # 在SSH会话中，将消息作为命令执行
        command = message.strip()
        
        if command.startswith("/ssh"):
            # 如果用户发送的是SSH命令，不作为普通命令执行
            return False
        
        # 执行命令
        try:
            result = execute_command(command)
            import asyncio
            asyncio.create_task(send_reply(websocket, data, f"```\n{result}\n```"))
        except Exception as e:
            import asyncio
            asyncio.create_task(send_reply(websocket, data, f"❌ 执行命令时出错: {str(e)}"))
        
        return True
    
    return False

def execute_command(command):
    """
    执行终端命令
    :param command: 命令字符串
    :return: 命令执行结果
    """
    try:
        # 使用shlex.split处理命令参数
        # 直接使用subprocess.run执行命令
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=None  # 无超时限制
        )
        
        # 返回stdout和stderr的组合结果
        output = result.stdout
        if result.stderr:
            output += "\n错误: " + result.stderr
        
        # 限制输出长度以避免消息过长
        if len(output) > 2000:
            output = output[:1997] + "..."
        
        if output.strip() == "":
            output = "命令执行完成，无输出。"
        
        return output
    except subprocess.TimeoutExpired:
        return "❌ 命令执行超时"
    except Exception as e:
        return f"❌ 命令执行失败: {str(e)}"

def on_load():
    """插件加载时的初始化"""
    print("SSH终端插件已加载")
    print("使用 /ssh start 开始会话，/ssh stop 结束会话")

def on_command(websocket, data, command, bot_id):
    """
    处理命令
    :param websocket: WebSocket连接
    :param data: 消息数据
    :param command: 命令内容
    :param bot_id: 机器人ID
    :return: True if handled, False otherwise
    """
    # 重用 on_message 的功能
    return False  # 使用 on_message 处理

async def send_reply(websocket, data, reply):
    """
    发送回复
    :param websocket: WebSocket连接
    :param data: 原始消息数据
    :param reply: 回复内容
    """
    try:
        # 构造回复消息
        if data.get("message_type") == "group":
            msg_data = {
                "action": "send_group_msg",
                "params": {
                    "group_id": data.get("group_id"),
                    "message": reply
                }
            }
        else:
            msg_data = {
                "action": "send_private_msg",
                "params": {
                    "user_id": data.get("user_id"),
                    "message": reply
                }
            }
        
        await websocket.send(json.dumps(msg_data))
    except Exception as e:
        print(f"发送回复时出错: {e}")